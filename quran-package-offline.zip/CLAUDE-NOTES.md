# Notes for Claude — المصحف المسموع (quran.atrakchi.contact)

- PWA (index.html), RTL Arabic, OFFLINE-FIRST. Text: bundled `quran-data.js` (window.QURAN {n:names, v:verses}; from quran-json/quranenc, split on spaces = Quran.com word positions). Fonts: bundled in `fonts/` (Amiri Quran, Cairo 400/600). Audio + word segments: Quran.com API v4 `chapter_recitations?segments=true`, streamed online or downloaded to IndexedDB (`quran-offline`, key `reciter:surah` -> {blob, stamps}). `sw.js` = app-shell cache (bump VERSION on changes; external origins not intercepted). No backend, no analytics.
- localStorage keys: `surah`, `reciter` only. IndexedDB holds downloaded audio. Untested against live Quran.com (sandbox had no access): verify audio CORS + word highlighting after first deploy.
- Hosting: GitHub -> Vercel; domain via Squarespace. Owner uploads to GitHub himself (needs .zip, <100 files per upload, no image files in packages).
- Colours: Atrakchi Family Style v1 (paper/night). Accent teal #1E6B66 / night #7FC4BA, header band #292B27 / #141513. App follows prefers-color-scheme; legal pages follow localStorage `fx-theme` then system.
- splash.js: dedication screen (7 s, tap-to-skip after 3 s, once per session, `?splash=1` forces). Photo `muadhin.jpg` (repo root) with fallback `icons/icon-512.png`. Tell the owner if the photo is added; no code change needed.
- Legal pages: privacy.html / terms.html (mention Quran.com + Google Fonts + Vercel logs). If features change (ads, analytics, accounts), update privacy.html and the Play Data safety form.
- Footer credit (every page): داود الاطرقجي للاستشارات الهندسية, https://www.atrakchi.com/, info@atrakchi.com
- Google Play: personal developer account -> closed testing (12 testers, 14 days) before production; TWA via PWABuilder; assetlinks.json in /.well-known/.
- Icons live in `icons/` (not part of packages): icon-192/512, icon-maskable-192/512, apple-touch-icon, favicon-32, icon.svg.
